insert into report_job_config (JOB_ID, JOB_NAME, JOB_CLASS_NAME, JOB_TIME, JOB_STAUTS, JUST_WORKDATE_RUN, JOB_REMARK, JOB_LST_TM, JOB_LST_TRL, SYSNAME, COUNTRY, STATUS)
values ('100007', 'DetailReportGeneJob', 'com.huateng.hsbc.job.DetailReportGeneJob', '0 0 23 * * ?', '1', 'N', 'DetailReportGeneJob', '20180530102335', '002', 'OTHER', 'IDHBAP', '1');
